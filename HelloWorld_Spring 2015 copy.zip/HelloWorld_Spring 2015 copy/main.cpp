/* 
 * File:   main.cpp
 * Author: Nick_Lussier
 * HelloWorld Spring 2015
 * Created on February 18, 2015, 7:46 AM
 */

#include <iostream>

using namespace std;
//user libraries
//global constants
//function prototypes

//execution beyond this point
int main(int argc, char** argv) {
    cout<<"Hello world!";
    return 0;
}

